# ElectronicsProject
Backend for project index app
Project created for needs of Electronics Basics subject
